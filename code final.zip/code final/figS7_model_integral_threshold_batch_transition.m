
clear all
close all


doubling_time1 = 97;                    % min
l1 = log(2)./doubling_time1;            % min^-1
doubling_time2 = 33;                    % min
l2 = log(2)./doubling_time2;            % min^-1
trans_time = 100;
tt = trans_time+200;                    % (min)
dt = 0.01;   
ot = 100; % (min)
tlist = 0:dt:tt;            
otlist = 0:dt*ot:tt;
tc = 40;
l_trans = nan(size(tlist));
l_trans(1:trans_time/dt) = l1;
l_trans(trans_time/dt:(trans_time+tc)/dt) = l1 + (l2-l1)/tc*(tlist(trans_time/dt:(trans_time+tc)/dt)-trans_time) ;
l_trans(1:trans_time/dt) = l1;
l_trans((trans_time+tc)/dt:end) = l2;
l_trans_hr = l_trans*60;
CpD_trans = (0.99*l_trans_hr+0.27)./l_trans_hr *60; 

all_ot = otlist;
all_l_trans = l_trans(1:ot:end);
all_CpD_trans = CpD_trans(1:ot:end);
all_oM = nan(10,length(otlist));
all_oN = nan(10,length(otlist));
all_NGR = nan(10,length(otlist)-1);
all_trans_time = trans_time(1:ot:end);


%%
for ps = 0:9

    %% parameters
    N0 = 10^4;                  % initial cell number 
    load batch_steady_state.mat;
    m = ms(ceil(length(ms)*rand(1,N0)));
    L = Ls(ceil(length(Ls)*rand(1,N0)));    

    m0 = 1;                  
    Lc = 1/2/log(2);
    epsilon_L = 0.01;

    doubling_time1 = 97;                    % min
    l1 = log(2)./doubling_time1;            % min^-1
    l1hr = l1*60;
    CpD1 = (0.99*l1hr+0.27)./l1hr *60; 

    doubling_time2 = 33;                    % min
    l2 = log(2)./doubling_time2;            % min^-1
    l2hr = l2*60;
    CpD2 = (0.99*l2hr+0.27)./l2hr *60; 
    
    trans_time = 100+9.7*ps;
    tt = trans_time+200;                    % (min)
    dt = 0.01;                  % (min)
    tlist = 0:dt:tt;            
    otlist = 0:dt*ot:tt;
    ot = 100;                   
    tc = 40;
    l_trans = nan(size(tlist));
    l_trans(1:trans_time/dt) = l1;
    l_trans(trans_time/dt:(trans_time+tc)/dt) = l1 + (l2-l1)/tc*(tlist(trans_time/dt:(trans_time+tc)/dt)-trans_time) ;
    l_trans(1:trans_time/dt) = l1;
    l_trans((trans_time+tc)/dt:end) = l2;
    l_trans_hr = l_trans*60;
    CpD_trans = (0.99*l_trans_hr+0.27)./l_trans_hr *60; 

%     figure();
%     yyaxis right
%     plot(tlist,l_trans,'linewidth',2); hold all
%     ylabel('\lambda');
%     yyaxis left
%     plot(tlist,CpD_trans,'linewidth',2); hold all
%     ylabel('C+D (min)')
%     xlabel('time');
%     title('growth rate transition function');
%     drawnow


    %% main loop
    N = N0;
    om = nan(ceil(length(tlist)/ot),2^6*N0);
%     om_mean = nan(ceil(length(tlist)/ot),1);
    oN = nan(ceil(length(tlist)/ot),1);
    oM = nan(ceil(length(tlist)/ot),1);

    CpD = CpD1;
    l = l1;
    disp(['phase' num2str(ps)]);
    for it = 1:length(tlist)
        l = l_trans(it);
        CpD = CpD_trans(it);

        m = m + dt*l*m;
        L = L + 1/(CpD).*m./m0 *dt + m./m0.*epsilon_L.*randn(1,N)*sqrt(dt)*sqrt(2);

        ifdiv = L>=Lc;

        N = N + sum(ifdiv);

        m(ifdiv) = m(ifdiv)/2;
        m = [m m(ifdiv)];
        L(ifdiv) = L(ifdiv)*0;
        L = [L L(ifdiv)];

        if rem(it,ot)==0
            om(it/ot,1:N) = m;
            oN(it/ot) = N;
        end
    end


    %%
    GR = (oN(2:end)-oN(1:end-1))/(dt*ot)./((oN(2:end)+oN(1:end-1))/2);
    for i = 1:ceil(length(tlist)/ot)
        oM(i) = nansum(om(i,:));
    end
    phase{ps+1}.ot = otlist;
    phase{ps+1}.l_trans = l_trans;
    phase{ps+1}.oN = oN;
    phase{ps+1}.GR = GR;
    phase{ps+1}.oM = oM;
    
    all_oM(ps+1,1:length(oM(round(9.7*ps)+1:end))) = oM(round(9.7*ps)+1:end);
    all_oN(ps+1,1:length(oN(round(9.7*ps)+1:end))) = oN(round(9.7*ps)+1:end);
    all_NGR(ps+1,1:length(GR(round(9.7*ps)+1:end))) = GR(round(9.7*ps)+1:end);

end
all_oM_mean = mean(all_oM);
all_oN_mean = mean(all_oN);
all_NGR_mean = mean(all_NGR);

%%
h2=figure();
yyaxis left
plot(all_ot, all_l_trans); 
yyaxis right
plot(all_ot, all_CpD_trans);

%% compare
load exp_upshift;

h3=figure();
exp_trans = 8;
sim_trans = 101;
semilogy(all_ot,all_oN_mean/all_oN_mean(sim_trans),'b','linewidth',2); hold all
semilogy(exp_time+100,exp_num/exp_num(exp_trans),'bo','linewidth',2); hold all
semilogy([all_trans_time all_trans_time],[10^-2 10^2],'k--','linewidth',2); hold all
semilogy(all_ot,all_oM_mean/all_oM_mean(sim_trans),'r','linewidth',2); hold all
semilogy(exp_time+100,exp_OD/exp_OD(exp_trans),'ro','linewidth',2); hold all
ylabel('relative value');
ax = gca();
ax.YScale = 'log';
xlim([0 250]);

%% compare rates

exp_OD_smooth = smooth(exp_OD,2);
exp_GR = (exp_OD_smooth(2:end)-exp_OD_smooth(1:end-1))./(exp_time(2:end)-exp_time(1:end-1))./((exp_OD_smooth(2:end)+exp_OD_smooth(1:end-1))/2);

exp_num_smooth = smooth(exp_num,3);
exp_GR_num = (exp_num_smooth(2:end)-exp_num_smooth(1:end-1))./(exp_time(2:end)-exp_time(1:end-1))./((exp_num_smooth(2:end)+exp_num_smooth(1:end-1))/2);
exp_time_GR = (exp_time(2:end)+exp_time(1:end-1))/2;
lN = (all_oN_mean(3:end)-all_oN_mean(1:end-2))/2/(dt*ot)./((all_oN_mean(3:end)+all_oN_mean(1:end-2))/2);

h4 = figure();
plot(all_ot(2:end-1),lN,'linewidth',2,'Color',[0 0.4470 0.7410]); hold all
plot(exp_time_GR+100,exp_GR_num ,'o','linewidth',2,'Color',[0 0.4470 0.7410]); hold all
plot(all_ot,all_l_trans,'linewidth',2,'Color',[0.8500 0.3250 0.0980]); hold all
plot(exp_time_GR+100,exp_GR,'o','linewidth',2,'Color',[0.8500 0.3250 0.0980]); hold all
semilogy([all_trans_time all_trans_time],[0 0.035],'k--','linewidth',2); hold off
ylim([0 0.035]);
ylabel('\lambda');
xlabel('time');
title('growth rate transition function');
legend('experiment \lambda_N','simulation \lambda_N','experiment \lambda_M','simulation \lambda_M','location','nw')
xlim([0 250])


%% cellular mass dynamics

h5 = figure();

plot(exp_time+100,exp_OD./exp_num/(exp_OD(exp_trans)/exp_num(exp_trans)),'o','linewidth',2); hold all
plot(all_ot,all_oM_mean./all_oN_mean/(all_oM_mean(sim_trans)/all_oN_mean(sim_trans)),'-','linewidth',2); hold all
plot([all_trans_time all_trans_time],[0 3],'k--','linewidth',2); hold off

xlabel('time');
ylabel('cellular mass');
title('cellular mass dynamics');
xlim([0 250]);
