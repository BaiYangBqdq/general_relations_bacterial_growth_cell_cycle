
clear all
close all

%% parameters

N0 = 10^5;                  % cell number 
m0 = 1;                     % cell mass constant 
Lc = 1/2/log(2);            % threshold
epsilon = 0.01;             % noise
dt = 0.01;                  % s

%%

doubling_time = 24.2 ;                  % min
l = log(2)/doubling_time;               % min^-1
lhr = l*60;                             % hr^-1
CpD = (0.99*lhr+0.27)./lhr *60;         % min
m = ones(1,N0)*m0*l*CpD;                % cellumlar mass
L = zeros(1,N0);  

total_doublings = 25;
tt = doubling_time * total_doublings;   % total time (min)
tlist = 0:dt:tt;                        % time list

Ndouble = total_doublings + 10;
steady_range = 10:20;


%% main loop

div_ind = ones(1,N0);
div_mass = nan(total_doublings+2,N0);
div_time = nan(total_doublings+2,N0);

for it = 1:length(tlist)
    disp([num2str(it) '/' num2str(length(tlist))]);
    m = m + dt*l*m;
    L = L + 1/(CpD).*m./m0 *dt + m./m0.*epsilon.*randn(1,N0)*sqrt(dt)*sqrt(2);

    ifdiv = L>=Lc;
    ifdiv_ind = find(ifdiv==1);
    for i = 1:length(ifdiv_ind)
        div_mass(div_ind(ifdiv_ind(i)),ifdiv_ind(i)) = m(ifdiv_ind(i));
        div_time(div_ind(ifdiv_ind(i)),ifdiv_ind(i)) = tlist(it);
    end
    m(ifdiv) = m(ifdiv)/2;
    L(ifdiv) = 0;

    div_ind(ifdiv) =  div_ind(ifdiv)+1;

end

%% analysis
birth_mass = div_mass(1:end-1,:)/2;
adder_mass = div_mass(2:end,:)-birth_mass;
DT = div_time(2:end,:)-div_time(1:end-1,:);

steady_birth_mass = birth_mass(steady_range,:);
steady_div_mass = div_mass(steady_range,:);
steady_DT = DT(steady_range,:);
steady_adder_mass = adder_mass(steady_range,:);

sbm = steady_birth_mass(:); 
sam = steady_adder_mass(:); 
sdm = steady_div_mass(:);    
sDT = steady_DT(:);         

norm_BM = sbm/nanmean(sbm);
norm_BM(isnan(norm_BM))=[];
norm_DM = sdm/nanmean(sdm);
norm_DM(isnan(norm_DM))=[];
norm_AM = sam/nanmean(sam);
norm_AM(isnan(norm_AM))=[];
norm_DT = sDT/nanmean(sDT);
norm_DT(isnan(norm_DT))=[];

%% analysis
bm_bin = 0.05;
bm_edge = 0:bm_bin:2;
bm_center = (bm_edge(2:end)+bm_edge(1:end-1))/2;

adder_mean = nan(size(bm_center));  adder_std = nan(size(bm_center));  adder_sem = nan(size(bm_center));
div_mean = nan(size(bm_center));    div_std = nan(size(bm_center));     div_sem = nan(size(bm_center));
DT_mean = nan(size(bm_center));     DT_std = nan(size(bm_center));      DT_sem = nan(size(bm_center));

Y = discretize(norm_BM,bm_edge);
for id = 1:length(bm_center)
    if sum(Y==id)>0.01*N0
        adder_mean(id) = nanmean(norm_AM(Y==id));
        adder_std(id) = nanstd(norm_AM(Y==id));
        adder_sem(id) = adder_std(id)/sum(Y==id)^0.5;
        div_mean(id) = nanmean(norm_DM(Y==id));
        div_std(id) = nanstd(norm_DM(Y==id));
        div_sem(id) = div_std(id)/sum(Y==id)^0.5;
        DT_mean(id) = nanmean(norm_DT(Y==id));
        DT_std(id) = nanstd(norm_DT(Y==id));
        DT_sem(id) = DT_std(id)/sum(Y==id)^0.5;
    end
end

%% plot

h=figure();

errorbar(bm_center,DT_mean, DT_sem,'o','linewidth',2); hold all
errorbar(bm_center,adder_mean,adder_sem,'o','linewidth',2); hold all
errorbar(bm_center,div_mean,div_sem,'o','linewidth',2); hold all
plot(bm_center,ones(size(bm_center)),'k--');
legend('inter-division time','added mass','division mass');
xlabel('normalized birth mass');
ylabel('relative value');
xlim([0.6 1.4]);
ylim([0 2]);


% saveas(h,'model_integral_threshold_mothermachine_adder','fig');
% saveas(h,'model_integral_threshold_mothermachine_adder','png');

