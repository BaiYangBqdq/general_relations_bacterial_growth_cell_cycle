% model hwa 20181127

clear all
close all

%% parameters
N0 = 15;                    % number of cases 
m0 = 1;                     % cell mass constant
Lc = 1/2/log(2);
b = 0.625;
mp = m0/b;
mpp = m0/(1-b);

doubling_time = [ 27.5 28.9 30.3 30.7 36.2 40.7 48.3 55.9 56.1 72.0 85.0 87.2 89.5 95.7 104.2];

l = log(2)./doubling_time;              % min^-1
lhr = l*60;
CpD = (0.99*lhr+0.27)./lhr *60;  
C = CpD*b;
D = CpD*(1-b);

points_per_doubling = 100;
dt = doubling_time / points_per_doubling ;                    % (min)
total_doublings = 30;
tt = doubling_time * total_doublings;                    % (min)
for i = 1:N0
    tlist(:,i) = 0:dt:tt;               % time list
end

bm_bin = 0.1;
bm_edge = 0:bm_bin:10;
bm_center = (bm_edge(2:end)+bm_edge(1:end-1))/2;


%% main loop CpD
om = nan(length(tlist),N0);
ox = nan(length(tlist),N0);
div = nan(length(tlist),N0);
m = ones(1,N0);   
L = zeros(1,N0);   

for it = 1:points_per_doubling*total_doublings+1

    m = m + dt.*l.*m;
    y = 1./CpD.*m;
    L = L + y.*dt;

    ifdiv = L>=Lc;

    m(ifdiv) = m(ifdiv)/2;
    L(ifdiv) = 0;

    om(it,:) = m;
    ox(it,:) = L;
    div(it,ifdiv) = 1;
end



%% main loop C
om_C = nan(length(tlist),N0);
ox_C = nan(length(tlist),N0);
div_C = nan(length(tlist),N0);
m = ones(1,N0);   
L = zeros(1,N0);   

for it = 1:points_per_doubling*total_doublings+1

    m = m + dt.*l.*m;
    y = 1./C.*m./mp;
    L = L + y.*dt;

    ifdiv = L>=Lc;

    m(ifdiv) = m(ifdiv)/2;
    L(ifdiv) = 0;

    om_C(it,:) = m;
    ox_C(it,:) = L;
    div_C(it,ifdiv) = 1;
end


%% main loop D
om_D = nan(length(tlist),N0);
ox_D = nan(length(tlist),N0);
div_D = nan(length(tlist),N0);
m = ones(1,N0);   
L = zeros(1,N0);   

for it = 1:points_per_doubling*total_doublings+1

    m = m + dt.*l.*m;
    y = 1./D.*m./mpp;
    L = L + y.*dt;

    ifdiv = L>=Lc;

    m(ifdiv) = m(ifdiv)/2;
    L(ifdiv) = 0;

    om_D(it,:) = m;
    ox_D(it,:) = L;
    div_D(it,ifdiv) = 1;
end

%% linear relation
h = figure('position',[100 100 900 300]);
subplot(1,3,1)
div_m = nan(total_doublings+10,N0);
for ic= 1:N0
    div_ind = find(div(:,ic)==1);
    div_m(1:length(div_ind),ic) = om(div_ind,ic)*2;
end
div_mass = div_m(2:end,:);
ss_div_mass = nanmean(div_mass(25:30,:),1);

plot(l.*CpD,log(2)*ss_div_mass,'o','linewidth',2); hold all
plot([0:3],[0:3],'k--','linewidth',2); hold all
ylabel('average cell mass');
xlabel('\lambda(C+D)');
title('linear relation');
ylim([0 2.4]);
xlim([0 2.4])


subplot(1,3,2)
div_m_C = nan(total_doublings+10,N0);
for ic= 1:N0
    div_ind_C = find(div_C(:,ic)==1);
    div_m_C(1:length(div_ind_C),ic) = om_C(div_ind_C,ic)*2;
end
div_mass_C = div_m_C(2:end,:);
ss_div_mass_C = nanmean(div_mass_C(25:30,:),1);

plot(l.*C,log(2)*ss_div_mass_C,'o','linewidth',2); hold all
plot([0:3],mp*[0:3],'k--','linewidth',2); hold all
ylabel('average cell mass');
xlabel('\lambdaC');
title('linear relation');
ylim([0 2.4]);
xlim([0 1.5])

subplot(1,3,3)
div_m_D = nan(total_doublings+10,N0);
for ic= 1:N0
    div_ind_D = find(div_D(:,ic)==1);
    div_m_D(1:length(div_ind_D),ic) = om_D(div_ind_D,ic)*2;
end
div_mass_D = div_m_D(2:end,:);
ss_div_mass_D = nanmean(div_mass_D(25:30,:),1);

plot(l.*D,log(2)*ss_div_mass_D,'o','linewidth',2); hold all
plot([0:3],mpp*[0:3],'k--','linewidth',2); hold all
ylabel('average cell mass');
xlabel('\lambdaD');
title('linear relation');
ylim([0 2.4]);
xlim([0 0.8])

%% save
% 
% saveas(h,'model_integral_mothermachine_singlecell_multicase','png');
% saveas(h,'model_integral_mothermachine_singlecell_multicase','fig');


