
clear all
close all

%% parameters

N0 = 10^5;                  % cell number 
m0 = 1;                     % cell mass constant 
Lc = 1/2/log(2);
epsilon_m = 0;
epsilon_L = 0.01;
dt = 0.01;

DTlist = [20 30 40 50 60 70];

dcx = 0.02; cx_sim = 0:dcx:2; 
scale_bm_pdf = nan(length(DTlist),length(cx_sim));
scale_dm_pdf = nan(length(DTlist),length(cx_sim));
scale_dt_pdf = nan(length(DTlist),length(cx_sim));

%%
for idt = 1:length(DTlist)
    disp(['case ' num2str(idt)]);
    doubling_time = DTlist(idt) ;           % min

    l = log(2)/doubling_time;               % min^-1
    lhr = l*60;
    CpD = (0.99*lhr+0.27)./lhr *60;         % min
    m = ones(1,N0)*m0*l*CpD;    
    L = zeros(1,N0);  

    total_doublings = 20;
    tt = doubling_time * total_doublings;   % (min)
    tlist = 0:dt:tt;                        % time list

    Ndouble = total_doublings + 10;
    steady_range = 10:18;

    bm_bin = 0.1;
    bm_edge = 0:bm_bin:10;
    bm_center = (bm_edge(2:end)+bm_edge(1:end-1))/2;

    %% main loop

    div_ind = ones(1,N0);
    div_mass = nan(total_doublings+2,N0);
    div_time = nan(total_doublings+2,N0);

    for it = 1:length(tlist)

        m = m + dt*l*m;
        L = L + 1/(CpD).*m./m0 *dt + m./m0.*epsilon_L.*randn(1,N0)*sqrt(dt)*sqrt(2);

        ifdiv = L>=Lc;
        ifdiv_ind = find(ifdiv==1);
        for i = 1:length(ifdiv_ind)
            div_mass(div_ind(ifdiv_ind(i)),ifdiv_ind(i)) = m(ifdiv_ind(i));
            div_time(div_ind(ifdiv_ind(i)),ifdiv_ind(i)) = tlist(it);
        end
        m(ifdiv) = m(ifdiv)/2;
        L(ifdiv) = 0;

        div_ind(ifdiv) =  div_ind(ifdiv)+1;
    end

    birth_mass = div_mass(1:end-1,:)/2;
    DT = div_time(2:end,:)-div_time(1:end-1,:);

    steady_birth_mass = birth_mass(steady_range,:);
    steady_div_mass = div_mass(steady_range,:);
    steady_DT = DT(steady_range,:);

    sbm = steady_birth_mass(:);  bm_mean(idt) = nanmean(steady_birth_mass(:));  bm_std(idt) = std(steady_birth_mass(:));  norm_bm_std(idt) = std(steady_birth_mass(:)/bm_mean(idt));
    sdm = steady_div_mass(:);    dm_mean(idt) = nanmean(steady_div_mass(:));    dm_std(idt) = std(steady_div_mass(:));      norm_dm_std(idt) = std(steady_div_mass(:)/dm_mean(idt));
    sDT = steady_DT(:);          dt_mean(idt) = nanmean(steady_DT(:));          dt_std(idt) = std(steady_DT(:));        norm_dt_std(idt) = std(steady_DT(:)/dt_mean(idt));

    norm_BM = sbm/nanmean(steady_birth_mass(:));
    norm_BM(isnan(norm_BM))=[];
    [cbir, ~]=hist(norm_BM(:),cx_sim);
    pdf_norm_BM = cbir/length(norm_BM)/dcx;
    scale_bm_pdf(idt,:) = pdf_norm_BM ;

    norm_DM = sdm(:)/nanmean(steady_div_mass(:));
    norm_DM(isnan(norm_DM))=[];
    [cdiv, ~]=hist(norm_DM,cx_sim);
    pdf_norm_DM = cdiv/length(norm_DM)/dcx;
    scale_dm_pdf(idt,:) = pdf_norm_DM;

    norm_DT = sDT(:)/nanmean(steady_DT(:));
    norm_DT(isnan(norm_DT))=[];
    [cdt, ~]=hist(norm_DT,cx_sim);
    pdf_norm_DT = cdt/length(norm_DT)/dcx;
    scale_dt_pdf(idt,:) = pdf_norm_DT;

end
disp('calculation done!');

%%
hc=figure('position',[100 100 900 300]);
cj = colormap('jet');
mcj = cj(1:floor(64/length(DTlist)):64,:);
for idt = 1:length(DTlist)
    subplot(1,3,1)
    plot(cx_sim,scale_bm_pdf(idt,:),'linewidth',2,'color',mcj(idt,:)); hold all
    xlabel('scaled birth mass');       ylabel('PDF');       
    subplot(1,3,2)
    plot(cx_sim,scale_dm_pdf(idt,:),'linewidth',2,'color',mcj(idt,:)); hold all
    xlabel('scaled  mass');       ylabel('PDF');       
    subplot(1,3,3)
    plot(cx_sim,scale_dt_pdf(idt,:),'linewidth',2,'color',mcj(idt,:)); hold all
    legends{idt} = ['DT = ' num2str(DTlist(idt)) 'min'];
    xlabel('scaled inter-division time');       ylabel('PDF');       
end

%% compare
load data_elf_scalling.mat
legends{idt+1}='elf DnaQ fast';
legends{idt+2}='elf DnaQ intermediate';
legends{idt+3}='elf DnaQ slow';
legends{idt+4}='elf SeqA intermediate';
legends{idt+5}='elf SeqA slow';
subplot(1,3,1)
plot(cx,pdf_norm_bm_elf_DnaQ_fast,'o','linewidth',1);  hold all
plot(cx,pdf_norm_bm_elf_DnaQ_intermediate,'o','linewidth',1);  hold all
plot(cx,pdf_norm_bm_elf_DnaQ_slow,'o','linewidth',1);  hold all
plot(cx,pdf_norm_bm_elf_SeqA_intermediate,'o','linewidth',1);  hold all
plot(cx,pdf_norm_bm_elf_SeqA_slow,'o','linewidth',1);  hold all
xlabel('scaled birth mass');       ylabel('PDF');       
subplot(1,3,2)
plot(cx,pdf_norm_dm_elf_DnaQ_fast,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dm_elf_DnaQ_intermediate,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dm_elf_DnaQ_slow,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dm_elf_SeqA_intermediate,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dm_elf_SeqA_slow,'o','linewidth',1);  hold all
xlabel('scaled div mass');       ylabel('PDF');       
subplot(1,3,3)
plot(cx,pdf_norm_dt_elf_DnaQ_fast,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dt_elf_DnaQ_intermediate,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dt_elf_DnaQ_slow,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dt_elf_SeqA_intermediate,'o','linewidth',1);  hold all
plot(cx,pdf_norm_dt_elf_SeqA_slow,'o','linewidth',1);  hold all
xlabel('scaled inter-division time');       ylabel('PDF');

%% data suckjoon
load('data_suckjoon_scalling.mat');
legends{idt+6}='exp suckjoon TSB';
legends{idt+7}='exp suckjoon synt rich';
legends{idt+8}='exp suckjoon sorb';
legends{idt+9}='exp suckjoon gly';
legends{idt+10}='exp suckjoon glu';
legends{idt+11}='exp suckjoon glu6aa';
legends{idt+12}='exp suckjoon glu12aa';

subplot(1,3,1)
plot(cx, pdf_bm_TSB,'o','linewidth',1); hold all
plot(cx, pdf_bm_sr,'o','linewidth',1); hold all
plot(cx, pdf_bm_sorb,'o','linewidth',1); hold all
plot(cx, pdf_bm_gly,'o','linewidth',1); hold all
plot(cx, pdf_bm_glu,'o','linewidth',1); hold all
plot(cx, pdf_bm_glu6,'o','linewidth',1); hold all
plot(cx, pdf_bm_glu12,'o','linewidth',1); hold all
subplot(1,3,2)
plot(cx, pdf_dm_TSB,'o','linewidth',1); hold all
plot(cx, pdf_dm_sr,'o','linewidth',1); hold all
plot(cx, pdf_dm_sorb,'o','linewidth',1); hold all
plot(cx, pdf_dm_gly,'o','linewidth',1); hold all
plot(cx, pdf_dm_glu,'o','linewidth',1); hold all
plot(cx, pdf_dm_glu6,'o','linewidth',1); hold all
plot(cx, pdf_dm_glu12,'o','linewidth',1); hold all
subplot(1,3,3)
plot(cx, pdf_dt_TSB,'o','linewidth',1); hold all
plot(cx, pdf_dt_sr,'o','linewidth',1); hold all
plot(cx, pdf_dt_sorb,'o','linewidth',1); hold all
plot(cx, pdf_dt_gly,'o','linewidth',1); hold all
plot(cx, pdf_dt_glu,'o','linewidth',1); hold all
plot(cx, pdf_dt_glu6,'o','linewidth',1); hold all
plot(cx, pdf_dt_glu12,'o','linewidth',1); hold all
drawnow


%% average cell mass
hm = figure();
llist = log(2)./DTlist*60;                  % hr^-1
CpDlist = (0.99*llist+0.27)./llist ;        % hr
plot(llist.*CpDlist,log(2).*dm_mean,'o','linewidth',2); hold all
plot([0:3],m0*[0:3],'k--','linewidth',2); hold all
ylabel('average cell mass');
xlabel('\lambda(C+D)');
title('linear relation');
ylim([0 3]);
xlim([0 3]);

%% std of cell mass

hstd = figure();
llist = log(2)./DTlist*60;                  % hr^-1
plot(llist,norm_dm_std,'o','linewidth',2); hold all
ylabel('std of scalled div mass');
xlabel('\lambda');

%%

hcl=figure('position',[100 100 900 300]);

for idt = 1:length(DTlist)
    subplot(1,3,1)
    plot(cx_sim,scale_bm_pdf(idt,:),'linewidth',2,'color',mcj(idt,:)); hold all
    xlabel('scaled birth mass');       ylabel('PDF');       
    subplot(1,3,2)
    plot(cx_sim,scale_dm_pdf(idt,:),'linewidth',2,'color',mcj(idt,:)); hold all
    xlabel('scaled  mass');       ylabel('PDF');       
    subplot(1,3,3)
    plot(cx_sim,scale_dt_pdf(idt,:),'linewidth',2,'color',mcj(idt,:)); hold all
    legends{idt} = ['DT = ' num2str(DTlist(idt)) 'min'];
    xlabel('scaled inter-division time');       ylabel('PDF');       
end
legend(legends,'location','best');
drawnow;

%% save
% 
% saveas(hcl,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001','png');
% saveas(hcl,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001','fig');
% 
% saveas(hc,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001_compare','png');
% saveas(hc,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001_compare','fig');
% 
% saveas(hm,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001_mbar','png');
% saveas(hm,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001_mbar','fig');
% 
% saveas(hstd,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001_mstd','png');
% saveas(hstd,'model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001_mstd','fig');
% 
% 
% clear hm hc hstd hcl
% save model_integral_threshold_mothermachine_stochastic_scalling_v4_rze001.mat