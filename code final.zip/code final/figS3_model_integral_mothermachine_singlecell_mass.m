% model hwa 20181127

clear all
close all

%% parameters
N0 = 3;                     % number of cases 
m0 = 1;                     % cell mass constant
Lc = 1/2/log(2);                 % threshold
m = [1 2 4];   

doubling_time = 24.2;       % min

l = log(2)./doubling_time;              % min^-1
lhr = l*60;
CpD = (0.99*lhr+0.27)./lhr *60; 

points_per_doubling = 100;
dt = doubling_time / points_per_doubling ;                    % (min)
total_doublings = 10;
tt = doubling_time * total_doublings;                    % (min)
for i = 1:N0
    tlist(:,i) = 0:dt:tt;               % time list
end

bm_bin = 0.1;
bm_edge = 0:bm_bin:10;
bm_center = (bm_edge(2:end)+bm_edge(1:end-1))/2;


%% main loop CpD
om = nan(length(tlist),N0);
ox = nan(length(tlist),N0);
div = nan(length(tlist),N0);

L = zeros(1,N0);   

for it = 1:points_per_doubling*total_doublings+1

    m = m + dt.*l.*m;
    y = 1./CpD.*m;
    L = L + y.*dt;

    ifdiv = L>=Lc;

    m(ifdiv) = m(ifdiv)/2;
    L(ifdiv) = 0;

    om(it,:) = m;
    ox(it,:) = L;
    div(it,ifdiv) = 1;
end

%%
h=figure();
plot(tlist,om);
xlabel('Time (min)');
ylabel('Cell mass');

%% save
% 
% saveas(h,'model_integral_mothermachine_singlecell_mass','png');
% saveas(h,'model_integral_mothermachine_singlecell_mass','fig');


